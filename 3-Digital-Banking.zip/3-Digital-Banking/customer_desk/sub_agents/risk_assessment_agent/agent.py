from google.adk.agents import Agent
from google.adk.tools.tool_context import ToolContext
#from google.adk import tool  # Required decorator

#@tool  # MUST add this decorator
def assess_risk(tool_context: ToolContext) -> dict:
    """Determines suitable account products"""
    return {
        "recommended_products": ["basic_checking", "debit_card"],
        "limits": {
            "daily_withdrawal": 1000,
            "initial_deposit": 500
        },
        "message":"Risk assessment is completed successfully"
    }

risk_assessment_agent = Agent(
    name="risk_assessment_agent",
    model="gemini-2.0-flash",
    description="Determines risk profile and product suitability",
    instruction="""
    Analyze these factors:
    1. KYC risk score
    2. Country of residence
    3. Intended account use
    4. Initial deposit amount
    
    Output must include:
    - Approved account types
    - Initial limits
    - Special conditions (if any)
    """,
    tools=[assess_risk],  
)