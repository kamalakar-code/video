from datetime import datetime

from google.adk.agents import Agent
from google.adk.tools.tool_context import ToolContext
#from google.adk import tool  # Required decorator

#@tool  # MUST add this decorator
def collect_documents(tool_context: ToolContext) -> dict:
  """Collects required onboarding documents"""

  document_id = "SSN"
  current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
  
  # Get current purchased courses
  current_submitted_docs = tool_context.state.get("submitted_docs", [])

  # Check if user already submitted the documents
  document_ids = [
    document["id"] for document in current_submitted_docs if isinstance(document, dict)
  ]
  if document_id in document_ids:
        return {"status": "error", "message": "You already have submitted the documents!"}

  # new_submitted_docs = [
  #   {"id":"Govt_id","name":"ssn"},
  #   {"id":"selfie","name":"photo"},
  #   {"id":"address","name":"phone_bill"}
  # ]

  # Create new list with the documents added
  new_submitted_docs = []
  # Only include valid dictionary documents
  for document in current_submitted_docs:
      if isinstance(document, dict) and "id" in document:
          new_submitted_docs.append(document)

  # Add the new course as a dictionary with id and purchase_date
  new_submitted_docs.append({"id": document_id, "uploaded_date": current_time})

  # Update purchased courses in state via assignment
  tool_context.state["submitted_docs"] = new_submitted_docs

  # Get current interaction history
  current_interaction_history = tool_context.state.get("interaction_history", [])

  # Create new interaction history with purchase added
  new_interaction_history = current_interaction_history.copy()

    # Update interaction history in state via assignment
  tool_context.state["interaction_history"] = new_interaction_history

  return {
      "status": "success",
      "message": "Successfully uploaded the Govt id", #, selfie, bill or address documents !",
      "document_id": document_id,
      "timestamp": current_time,
  } # ADK tools MUST return a dict

# Create the sales agent
document_collection_agent = Agent(
    name="document_collection_agent",
    model="gemini-2.0-flash",
    description="Document collection agent and validation",
    instruction="""
    You are a document collection agent 

    <user_info>
    Name: {user_name}
    </user_info>

    <purchase_info>
    Purchased Courses: {purchased_courses}
    </purchase_info>

    <interaction_history>
    {interaction_history}
    </interaction_history>

    When interacting with users:

    1. Check if they already submitted the documents (check document_ids above)
       - Document information is stored as objects with "id" properties
       - The document ids are "government_id","selfie_id","bill_id","bank_stmt_id" 

    2. If they have not:
       - If they want to upload or submit:
          - use collect_documents tool
          - confirm document submission
          - Ask if they can proceed with KYC process
  
    3. After any interaction:
       - The state will automatically track the interaction
       - Be ready to hand off to KYC agent after document collection

    Remember:
    - Be helpful but not pushy
    - Focus on the value and practical skills they'll gain
    - Emphasize the hands-on nature of building a real AI application
    """,
    tools=[collect_documents],
)