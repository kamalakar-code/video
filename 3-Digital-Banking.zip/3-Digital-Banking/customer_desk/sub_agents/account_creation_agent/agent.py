
from datetime import datetime

from google.adk.agents import Agent
from google.adk.tools.tool_context import ToolContext
#from google.adk import tool  # Required decorator

#@tool  # MUST add this decorator
def collect_create_accountno(tool_context: ToolContext) -> dict:
    """Collects user information, validates user entered information and creates an account creation checks using collected documents"""
    # Integration with actual KYC service would go here
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_kyc_status = []

    docs = tool_context.state.get("submitted_docs",[])
      
    # Get current purchased courses
    if(docs):
         new_kyc_status.append({"submitted_docs":docs, "status":"success", "approved_time": current_time})

    else :
          return {"status": "error", "message": "Your account creation is not successful"}

    # Update purchased courses in state via assignment
    tool_context.state["kyc_status"] = new_kyc_status

    # Get current interaction history
    current_interaction_history = tool_context.state.get("interaction_history", [])

    # Create new interaction history with purchase added
    new_interaction_history = current_interaction_history.copy()

      # Update interaction history in state via assignment
    tool_context.state["interaction_history"] = new_interaction_history
    
    
    return {
        "verified": True,
        "risk_score": 0.2,
        "message":"congratulations your account setup is completed and You are successfully onboarded to bank"
    }

account_creation_agent = Agent(
    name="account_creation_agent",
    model="gemini-2.0-flash",
    description="Account creation agent",
    instruction="""
    You are an account creation agent 

    <user_info>
    Name: {user_name}
    </user_info>

    <purchase_info>
    Purchased Courses: {purchased_courses}
    </purchase_info>

    <interaction_history>
    {interaction_history}
    </interaction_history>

    When interacting with users:

    1. Collect all below provided required fields from the user:
         - user name
         - password
         - email id
         - full name
    2. Field Requirements:
        - Username: 4+ characters
        - Email: Must contain '@' , '.'
        - Password: must be minimum length is 6 and maximum 32, one of special character(!,@,#,$,&,*), combination of alphabets, digits and special characters,One uppercase letter and a digit and a special character is a must in the password range
        - Full Name: Non-empty

    3. Error Handling:
        - Returns specific field errors
        - Maintains state until completion

    4. Success Case:
        - Returns complete user data
        - Once user fills in all the required fields without any errors then use the tool collect_create_accountno to confirm their account is created successfully
        - Changes status to 'complete'
  
    5. After any interaction:
       - Once user fills in all the required fields without any errors then use the tool collect_create_accountno to confirm their account is created successfully
       - The state will automatically track the interaction
       - Be ready to hand off to account summary agent

  Remember:
    - Be helpful but not pushy
    - Focus on the value and practical skills they'll gain
    - Emphasize the hands-on nature of building a real AI application,
    """,
    tools=[collect_create_accountno],  
    )

