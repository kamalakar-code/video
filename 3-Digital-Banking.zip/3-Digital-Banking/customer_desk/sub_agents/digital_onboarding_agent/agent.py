from google.adk.agents import Agent
from google.adk.tools.tool_context import ToolContext
#from google.adk import tool  # Required decorator

#@tool  # MUST add this decorator
def display_text(tool_context: ToolContext) -> dict:
    """Displays onboarding confirmation message"""
    print(f"I'm Onboarding Agent. Relax! and get ready for your new account shortly")
    return {"status": "success"}  # ADK tools MUST return a dict

digital_onboarding_agent = Agent(
    name="digital_onboarding_agent",
    model="gemini-2.0-flash",
    description="Onboarding agent",
    instruction="""
      When user requests for account opening then 
        1. The expected output you will show is as below 

             " Okay {user_name} , I can help you with that.

              To set up an account, I'll need to guide you through a few steps:

              1.  **Document Submission:** You'll need to submit a copy of your ID, a selfie, and proof of address.
              2.  **KYC/AML Compliance Checks:** I'll run these checks to verify your identity and ensure compliance.
              3.  **Risk Assessment:** I'll perform a risk assessment to determine the appropriate account type for you. "

        2. Confirm with the user if they are ready to submit their documents
        3. If user confirms yes are okay to submit their documents then transfer the call to the document_collection_agent else go to customer_desk agent
    """,
    tools=[display_text],  
)