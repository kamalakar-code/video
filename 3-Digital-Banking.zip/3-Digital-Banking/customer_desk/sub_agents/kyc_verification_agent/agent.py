from datetime import datetime

from google.adk.agents import Agent
from google.adk.tools.tool_context import ToolContext
#from google.adk import tool  # Required decorator

#@tool  # MUST add this decorator
def verify_kyc(tool_context: ToolContext) -> dict:
    """Performs KYC checks using collected documents"""
    # Integration with actual KYC service would go here
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_kyc_status = []

    docs = tool_context.state.get("submitted_docs",[])
      
    # Get current purchased courses
    if(docs):
         new_kyc_status.append({"submitted_docs":docs, "status":"success", "approved_time": current_time})

    else :
          return {"status": "error", "message": "Your KYC needs is not successful"}


    # Update purchased courses in state via assignment
    tool_context.state["kyc_status"] = new_kyc_status

    # Get current interaction history
    current_interaction_history = tool_context.state.get("interaction_history", [])

    # Create new interaction history with purchase added
    new_interaction_history = current_interaction_history.copy()

      # Update interaction history in state via assignment
    tool_context.state["interaction_history"] = new_interaction_history
    
    
    return {
        "verified": True,
        "risk_score": 0.2,
        "message":"Your KYC process is completed"
    }

kyc_verification_agent = Agent(
    name="kyc_verification_agent",
    model="gemini-2.0-flash",
    description="Performs identity verification and AML checks",
    instruction="""
    You are a KYC verification agent 

    <user_info>
    Name: {user_name}
    </user_info>

    <purchase_info>
    Purchased Courses: {purchased_courses}
    </purchase_info>

    <interaction_history>
    {interaction_history}
    </interaction_history>

    When interacting with users:

    1. if they are coming from document collectin then check documents are submitted from {submitted_docs} 
        - Confirm users their kyc verification is successfull 
        - use verify_kyc tool
        - confirm KYC success
        - Inform their account creation will be initiated now
  
    2. After any interaction:
       - The state will automatically track the interaction
       - Be ready to hand off to account summary agent

  Remember:
    - Be helpful but not pushy
    - Focus on the value and practical skills they'll gain
    - Emphasize the hands-on nature of building a real AI application,
    """,
    tools=[verify_kyc],  
    )

