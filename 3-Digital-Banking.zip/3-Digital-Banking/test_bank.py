import re
import random
from getpass import getpass
from enum import Enum, auto

class OnboardingStep(Enum):
    WELCOME = auto()
    ACCOUNT_CREATION = auto()
    COMPLETE = auto()

class OnboardingAgent:
    def __init__(self):
        self.current_step = OnboardingStep.WELCOME
        self.user_data = {}
        self.attempts = 0
        self.max_attempts = 3
    
    def _generate_account_number(self):
        return f"AC{random.randint(10000000, 99999999)}"
    
    def _validate_email(self, email):
        return re.match(r"[^@]+@[^@]+\.[^@]+", email)
    
    def process(self, user_input=None):
        if self.current_step == OnboardingStep.WELCOME:
            self.current_step = OnboardingStep.ACCOUNT_CREATION
            return {
                "message": "Welcome to our bank!\n\nCreate your account",
                "needs_input": True,
                "fields": ["username", "email", "password"],
                "hints": {
                    "password": "Min 8 characters",
                    "email": "Valid email address"
                }
            }
        
        elif self.current_step == OnboardingStep.ACCOUNT_CREATION:
            if user_input:
                # Validate input
                errors = []
                if len(user_input.get("username", "")) < 3:
                    errors.append("Username must be at least 3 characters")
                if not self._validate_email(user_input.get("email", "")):
                    errors.append("Invalid email format")
                if len(user_input.get("password", "")) < 8:
                    errors.append("Password must be at least 8 characters")
                
                if errors:
                    self.attempts += 1
                    if self.attempts >= self.max_attempts:
                        return {
                            "message": "Too many failed attempts. Please try again later.",
                            "fatal": True
                        }
                    return {
                        "message": "\n".join(["Please fix these errors:"] + errors),
                        "needs_input": True,
                        "fields": ["username", "email", "password"],
                        "hints": {
                            "password": "Min 8 characters",
                            "email": "Valid email address"
                        }
                    }
                
                # If validation passes
                self.user_data.update(user_input)
                self.user_data["account_number"] = self._generate_account_number()
                self.current_step = OnboardingStep.COMPLETE
                return {
                    "message": "Account created successfully!",
                    "account_details": self.user_data
                }
            
            return {
                "message": "Create your account",
                "needs_input": True,
                "fields": ["username", "email", "password"],
                "hints": {
                    "password": "Min 8 characters",
                    "email": "Valid email address"
                }
            }
        
        elif self.current_step == OnboardingStep.COMPLETE:
            return {
                "message": f"Onboarding complete!\nAccount Number: {self.user_data['account_number']}",
                "completed": True
            }

def collect_input(fields, hints=None):
    user_input = {}
    for field in fields:
        hint = f" ({hints[field]})" if hints and field in hints else ""
        while True:
            try:
                if field == "password":
                    value = getpass(f"{field}{hint}: ")
                else:
                    value = input(f"{field}{hint}: ")
                
                if not value.strip():
                    print("This field cannot be empty")
                    continue
                    
                user_input[field] = value.strip()
                break
            except KeyboardInterrupt:
                print("\nOperation cancelled")
                return None
    return user_input

def run_onboarding():
    agent = OnboardingAgent()
    response = agent.process()
    
    while not response.get("completed", False):
        print(f"\n{response['message']}")
        
        if response.get("fatal"):
            break
            
        if response.get("needs_input"):
            user_input = collect_input(
                response["fields"],
                response.get("hints")
            )
            if user_input is None:  # User cancelled
                break
            response = agent.process(user_input)
        else:
            response = agent.process()
    
    if response.get("completed"):
        print(f"\n{response['message']}")
        print("\nAccount Details:")
        for k, v in agent.user_data.items():
            if k != "password":
                print(f"{k}: {v}")

if __name__ == "__main__":
    run_onboarding()