# test_doc.py
import pytest
import asyncio
from Doc_validator_handler import DocumentCollectionHandler
from PIL import Image
import io

@pytest.fixture
def sample_id_image():
    img = Image.new('RGB', (800, 600), color='red')
    img_byte_arr = io.BytesIO()
    img.save(img_byte_arr, format='PNG')
    return img_byte_arr.getvalue()

@pytest.fixture
def sample_selfie_image():
    img = Image.new('RGB', (800, 600), color='blue')
    img_byte_arr = io.BytesIO()
    img.save(img_byte_arr, format='PNG')
    return img_byte_arr.getvalue()

@pytest.mark.asyncio
async def test_document_handler_flow(sample_id_image, sample_selfie_image):
    handler = DocumentCollectionHandler(session_id="test123")
    
    # Test initial document request
    request = {'intent': 'REQUEST_DOCUMENTS'}
    response = await handler.handle_webhook_request(request)
    assert 'fulfillment_response' in response
    
    # Test ID submission
    id_request = {
        'intent': 'SUBMIT_DOCUMENT',
        'parameters': {
            'doc_type': 'id',
            'content': sample_id_image
        }
    }
    id_response = await handler.handle_webhook_request(id_request)
    assert id_response.get('success', False)
    
    # Test selfie submission
    selfie_request = {
        'intent': 'SUBMIT_DOCUMENT',
        'parameters': {
            'doc_type': 'selfie',
            'content': sample_selfie_image
        }
    }
    selfie_response = await handler.handle_webhook_request(selfie_request)
    assert selfie_response.get('success', False)