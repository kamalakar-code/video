import logging
from typing import Dict, Optional, List
from datetime import datetime
from google.cloud import vision
from google.cloud.vision_v1 import types
import cv2
import numpy as np

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DocumentValidator:
    """Enhanced document validator using Google Cloud Vision API"""
    
    def __init__(self):
        self.client = vision.ImageAnnotatorClient()
    
    def validate_id_document(self, id_image: bytes) -> Dict:
        """Validate ID document with enhanced checks"""
        try:
            # Use Google Cloud Vision for more accurate OCR
            image = types.Image(content=id_image)
            text_response = self.client.document_text_detection(image=image)
            id_text = text_response.full_text_annotation.text
            
            validation_result = {
                'is_valid': False,
                'errors': [],
                'extracted_data': {}
            }
            
            # Enhanced date validation
            expiration_date = self._extract_date(id_text)
            if expiration_date and expiration_date < datetime.now().date():
                validation_result['errors'].append("ID expired")
            
            # Check for tampering
            if self._detect_tampering(id_image):
                validation_result['errors'].append("Document shows signs of tampering")
            
            # Extract data using improved patterns
            extracted_data = {
                'name': self._extract_name(id_text),
                'dob': self._extract_dob(id_text),
                'id_number': self._extract_id_number(id_text),
                'document_type': self._identify_document_type(id_text)
            }
            
            if all(extracted_data.values()):
                validation_result['extracted_data'] = extracted_data
            else:
                missing_fields = [k for k, v in extracted_data.items() if not v]
                validation_result['errors'].append(f"Missing fields: {', '.join(missing_fields)}")
            
            validation_result['is_valid'] = not validation_result['errors']
            return validation_result
            
        except Exception as e:
            logger.error(f"ID validation failed: {str(e)}")
            return {
                'is_valid': False,
                'error': "Technical error during validation"
            }
    
    def validate_selfie(self, selfie_image: bytes, id_image: bytes) -> Dict:
        """Enhanced face validation using Google Cloud Vision"""
        try:
            # Convert to Google Vision types
            selfie_img = types.Image(content=selfie_image)
            id_img = types.Image(content=id_image)
            
            # Detect faces
            selfie_faces = self.client.face_detection(image=selfie_img).face_annotations
            id_faces = self.client.face_detection(image=id_img).face_annotations
            
            if not selfie_faces or not id_faces:
                return {
                    'is_valid': False,
                    'error': "No faces detected"
                }
            
            # Simple comparison (for production, use FaceNet or similar)
            main_selfie_face = selfie_faces[0]
            main_id_face = id_faces[0]
            
            # Compare basic attributes
            match = (
                abs(main_selfie_face.detection_confidence - main_id_face.detection_confidence) < 0.2 and
                abs(main_selfie_face.joy_likelihood - main_id_face.joy_likelihood) < 1
            )
            
            return {
                'is_valid': match,
                'confidence': min(main_selfie_face.detection_confidence, main_id_face.detection_confidence),
                'error': None if match else "Face mismatch"
            }
            
        except Exception as e:
            logger.error(f"Face validation failed: {str(e)}")
            return {
                'is_valid': False,
                'error': "Technical error during face validation"
            }
            
    def validate_proof_of_address(self, address_doc: bytes) -> Dict:
        """Validate proof of address document"""
        try:
            # Use Google Cloud Vision for OCR
            image = types.Image(content=address_doc)
            text_response = self.client.document_text_detection(image=image)
            address_text = text_response.full_text_annotation.text
            
            # Check if document is recent (within last 3 months)
            doc_date = self._extract_date(address_text)
            if doc_date:
                months_diff = (datetime.now().date() - doc_date).days // 30
                if months_diff > 3:
                    return {
                        'is_valid': False,
                        'error': "Address proof is too old (must be within 3 months)"
                    }
            
            # Check for address components
            address_indicators = ['street', 'avenue', 'road', 'address', 'lane', 'boulevard']
            if not any(word in address_text.lower() for word in address_indicators):
                return {
                    'is_valid': False,
                    'error': "No valid address found in document"
                }
            
            # Extract address
            extracted_address = self._extract_address(address_text)
            if not extracted_address:
                return {
                    'is_valid': False,
                    'error': "Could not parse address from document"
                }
                
            return {
                'is_valid': True,
                'extracted_address': extracted_address
            }
            
        except Exception as e:
            logger.error(f"Address validation failed: {str(e)}")
            return {
                'is_valid': False,
                'error': "Technical error during address validation"
            }

    def _extract_address(self, text: str) -> Optional[str]:
        """Helper to extract address from text"""
        # Simple implementation - extract first line containing address keywords
        lines = text.split('\n')
        for line in lines:
            if any(word in line.lower() for word in ['street', 'avenue', 'road', 'address']):
                return line.strip()
        return None

class DocumentCollectionHandler:
    """ADK 7 Integrated Handler with Session Management"""
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.validator = DocumentValidator()
        self.required_docs = {
            'id': {
                'description': 'Government-issued ID (passport/driver license)',
                'validator': self.validator.validate_id_document,
                'max_size_mb': 5
            },
            'selfie': {
                'description': 'Recent selfie with neutral expression',
                'validator': self.validator.validate_selfie,
                'max_size_mb': 3
            },
            'address': {
                'description': 'Proof of address (utility bill/bank statement <3 months old)',
                'validator': self.validator.validate_proof_of_address,
                'max_size_mb': 5
            }
        }
        self.user_docs = {}
        self.validation_history = []
    
    async def handle_webhook_request(self, request: Dict) -> Dict:
        """ADK 7 Webhook Integration Point"""
        intent = request.get('intent')
        params = request.get('parameters', {})
        
        # Add session tracking
        params['session_id'] = self.session_id
        
        try:
            if intent == "REQUEST_DOCUMENTS":
                return await self._handle_request_documents(params)
            elif intent == "SUBMIT_DOCUMENT":
                return await self._handle_document_submission(params)
            elif intent == "FINAL_VERIFICATION":
                return await self._handle_final_verification(params)
            else:
                return self._error_response("Unsupported intent")
                
        except Exception as e:
            logger.error(f"Session {self.session_id} error: {str(e)}")
            return self._error_response("Processing error occurred")

    async def _handle_document_submission(self, params: Dict) -> Dict:
        """Async document processing with validation"""
        doc_type = params.get('doc_type')
        doc_content = params.get('content')
        
        if doc_type not in self.required_docs:
            return self._error_response("Invalid document type")
        
        # Validate file size
        max_size = self.required_docs[doc_type]['max_size_mb'] * 1024 * 1024
        if len(doc_content) > max_size:
            return self._error_response(f"Document too large (max {self.required_docs[doc_type]['max_size_mb']}MB)")
        
        # Special handling for selfie which needs ID reference
        if doc_type == 'selfie' and 'id' not in self.user_docs:
            return self._error_response("Please submit ID first")
        
        # Run validation
        validator = self.required_docs[doc_type]['validator']
        validation_result = (
            validator(doc_content, self.user_docs['id']['content'])
            if doc_type == 'selfie'
            else validator(doc_content)
        )
        
        # Store results
        self.validation_history.append({
            'timestamp': datetime.now().isoformat(),
            'doc_type': doc_type,
            'result': validation_result
        })
        
        if validation_result.get('is_valid'):
            self.user_docs[doc_type] = {
                'content': doc_content,
                'validation_data': validation_result,
                'submitted_at': datetime.now().isoformat()
            }
            
            # Determine next steps
            remaining_docs = [d for d in self.required_docs if d not in self.user_docs]
            if remaining_docs:
                next_action = {
                    'intent': 'SUBMIT_DOCUMENT',
                    'parameters': {
                        'expected_doc_type': remaining_docs[0],
                        'hint': self.required_docs[remaining_docs[0]]['description']
                    }
                }
            else:
                next_action = {
                    'intent': 'FINAL_VERIFICATION',
                    'parameters': {}
                }
            
            return {
                'session_id': self.session_id,
                'fulfillment_response': {
                    'message': {
                        'text': [f"{doc_type.replace('_', ' ').title()} validated successfully"]
                    }
                },
                'next_action': next_action,
                'payload': {
                    'validation_summary': validation_result
                }
            }
        
        else:
            return self._error_response(
                f"Validation failed: {validation_result.get('error', 'Unknown error')}",
                retry_action={
                    'intent': 'SUBMIT_DOCUMENT',
                    'parameters': {
                        'expected_doc_type': doc_type,
                        'hint': f"Re-submit {doc_type}: {self.required_docs[doc_type]['description']}"
                    }
                }
            )

    def _error_response(self, message: str, retry_action: Optional[Dict] = None) -> Dict:
        """Standard error response builder"""
        response = {
            'session_id': self.session_id,
            'fulfillment_response': {
                'message': {
                    'text': [message]
                }
            },
            'error': True
        }
        if retry_action:
            response['next_action'] = retry_action
        return response

# Example ADK 7 Webhook Integration
async def webhook_entry_point(request):
    """Google Cloud Function entry point"""
    request_json = await request.get_json()
    session_id = request_json.get('session', {}).get('id', 'default_session')
    
    handler = DocumentCollectionHandler(session_id)
    return await handler.handle_webhook_request(request_json)