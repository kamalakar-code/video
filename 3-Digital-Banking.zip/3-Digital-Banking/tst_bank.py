import logging
from typing import Dict, Any, Optional, List
from enum import Enum, auto
from getpass import getpass
import random
import string

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class OnboardingStep(Enum):
    """Enum representing the different steps in the onboarding process."""
    WELCOME = auto()
    ACCOUNT_CREATION = auto()
    IDENTITY_VERIFICATION = auto()
    PREFERENCES_SETUP = auto()
    SECURITY_SETUP = auto()
    COMPLETION = auto()


class OnboardingState:
    """Class to maintain the state of the onboarding process."""
    
    def __init__(self):
        self.current_step = OnboardingStep.WELCOME
        self.user_data: Dict[str, Any] = {}
        self.completed_steps: List[OnboardingStep] = []
        self.awaiting_input = False
        self.account_number = None
    
    def update_step(self, new_step: OnboardingStep):
        """Update the current step and add the previous step to completed steps."""
        if self.current_step != new_step:
            if self.current_step != OnboardingStep.WELCOME:
                self.completed_steps.append(self.current_step)
            self.current_step = new_step
            self.awaiting_input = new_step not in [OnboardingStep.WELCOME, OnboardingStep.COMPLETION]
    
    def add_user_data(self, key: str, value: Any):
        """Add user-provided data to the state."""
        self.user_data[key] = value
        self.awaiting_input = False
        
        # Generate account number after completing account creation
        if key == "account" and self.account_number is None:
            self.account_number = self._generate_account_number()
    
    def _generate_account_number(self) -> str:
        """Generate a random 10-digit account number."""
        return ''.join(random.choices(string.digits, k=10))


class OnboardingAgent:
    """Main agent class that handles the digital onboarding process."""
    
    def __init__(self):
        self.state = OnboardingState()
        self.security_questions = [
            "What was your first pet's name?",
            "What city were you born in?",
            "What was your mother's maiden name?",
            "What was the name of your first school?",
            "What was your childhood nickname?"
        ]
    
    def process_step(self, user_input: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process the current step in the onboarding process.
        
        Args:
            user_input: Optional input from the user for the current step.
            
        Returns:
            A dictionary containing the response for the current step.
        """
        try:
            if user_input is not None:
                self._handle_user_input(user_input)
            
            if not self.state.awaiting_input:
                self._transition_to_next_step()
            
            return self._generate_step_response()
            
        except Exception as e:
            logger.error(f"Error processing onboarding step: {e}")
            self.state.awaiting_input = True
            response = self._generate_step_response()
            response.update({
                "error": str(e),
                "retry_step": True
            })
            return response
    
    def _handle_user_input(self, user_input: Dict[str, Any]):
        """Process user input for the current step."""
        if not self.state.awaiting_input:
            return
            
        current_step = self.state.current_step
        
        if current_step == OnboardingStep.ACCOUNT_CREATION:
            self._validate_account_creation_input(user_input)
            self.state.add_user_data("account", user_input)
        elif current_step == OnboardingStep.IDENTITY_VERIFICATION:
            self._validate_identity_verification_input(user_input)
            self.state.add_user_data("identity", user_input)
        elif current_step == OnboardingStep.PREFERENCES_SETUP:
            self._validate_preferences_input(user_input)
            self.state.add_user_data("preferences", user_input)
        elif current_step == OnboardingStep.SECURITY_SETUP:
            security_data = {
                "security_questions": self._collect_security_questions()
            }
            self.state.add_user_data("security", security_data)
    
    def _generate_step_response(self) -> Dict[str, Any]:
        """Generate the appropriate response for the current step."""
        current_step = self.state.current_step
        response = {
            "current_step": current_step.name,
            "completed_steps": [step.name for step in self.state.completed_steps],
            "awaiting_input": self.state.awaiting_input,
        }
        
        if current_step == OnboardingStep.WELCOME:
            response.update({
                "message": "Welcome to our banking platform! Let's get you onboarded.",
                "next_actions": ["proceed_to_account_creation"]
            })
        elif current_step == OnboardingStep.ACCOUNT_CREATION:
            response.update({
                "message": "Please provide your account details.",
                "required_fields": ["username", "email", "password"],
                "field_descriptions": {
                    "username": "4-20 characters, letters and numbers only",
                    "email": "Your active email address",
                    "password": "Minimum 8 characters"
                }
            })
        elif current_step == OnboardingStep.IDENTITY_VERIFICATION:
            response.update({
                "message": "Please verify your identity.",
                "required_fields": ["full_name", "date_of_birth", "government_id"],
                "field_descriptions": {
                    "full_name": "As shown on government ID",
                    "date_of_birth": "YYYY-MM-DD format",
                    "government_id": "Passport/Driver's License number"
                }
            })
        elif current_step == OnboardingStep.PREFERENCES_SETUP:
            response.update({
                "message": "Please configure your preferences.",
                "required_fields": ["language", "timezone", "notification_preferences"],
                "options": {
                    "language": ["en", "es", "fr", "de"],
                    "timezone": ["UTC", "EST", "PST", "CET"]
                },
                "field_descriptions": {
                    "notification_preferences": "Receive notifications? (yes/no)"
                }
            })
        elif current_step == OnboardingStep.SECURITY_SETUP:
            response.update({
                "message": "Please set up your security questions.",
                "instructions": "You'll need to answer 3 security questions"
            })
        elif current_step == OnboardingStep.COMPLETION:
            response.update({
                "message": "Onboarding complete! Thank you for joining our platform.",
                "next_actions": ["access_dashboard", "view_profile", "start_tutorial"],
                "user_data_summary": self._get_user_data_summary()
            })
        
        return response
    
    def _get_user_data_summary(self) -> Dict[str, Any]:
        """Generate a summary of collected user data with sensitive information masked."""
        summary = {}
        user_data = self.state.user_data
        
        summary["account"] = {
            "account_number": self.state.account_number,
            "username": user_data["account"]["username"],
            "email": user_data["account"]["email"],
            "password": "****"
        }
        
        summary["identity"] = {
            "full_name": user_data["identity"]["full_name"],
            "date_of_birth": user_data["identity"]["date_of_birth"],
            "government_id": "****"
        }
        
        summary["preferences"] = user_data["preferences"]
        summary["security"] = {"security_questions": "****"}
        
        return summary
    
    def _transition_to_next_step(self):
        """Transition to the next step in the onboarding process."""
        step_order = {
            OnboardingStep.WELCOME: OnboardingStep.ACCOUNT_CREATION,
            OnboardingStep.ACCOUNT_CREATION: OnboardingStep.IDENTITY_VERIFICATION,
            OnboardingStep.IDENTITY_VERIFICATION: OnboardingStep.PREFERENCES_SETUP,
            OnboardingStep.PREFERENCES_SETUP: OnboardingStep.SECURITY_SETUP,
            OnboardingStep.SECURITY_SETUP: OnboardingStep.COMPLETION,
        }
        
        if self.state.current_step in step_order:
            self.state.update_step(step_order[self.state.current_step])
    
    def _collect_security_questions(self) -> Dict[str, Any]:
        """Collect security questions from user."""
        print("\n=== Security Questions Setup ===")
        print("Please select and answer 3 security questions from the following:")
        
        selected_questions = {}
        
        for i in range(3):
            print(f"\nQuestion {i+1}:")
            for idx, question in enumerate(self.security_questions, 1):
                print(f"{idx}. {question}")
            
            while True:
                try:
                    q_choice = int(input("Select a question (1-5): ")) - 1
                    if 0 <= q_choice < len(self.security_questions):
                        answer = input(f"Answer for '{self.security_questions[q_choice]}': ")
                        if not answer.strip():
                            print("Answer cannot be empty. Please try again.")
                            continue
                            
                        selected_questions[f"question_{i+1}"] = {
                            "question": self.security_questions[q_choice],
                            "answer": answer.lower().strip()
                        }
                        break
                    print("Please select a number between 1 and 5")
                except ValueError:
                    print("Invalid input. Please enter a number.")
        
        return selected_questions
    
    def _validate_account_creation_input(self, input_data: Dict[str, Any]):
        """Validate account creation input."""
        required_fields = ["username", "email", "password"]
        self._validate_required_fields(input_data, required_fields)
        
        if len(input_data["username"]) < 4 or len(input_data["username"]) > 20:
            raise ValueError("Username must be 4-20 characters long")
        if not input_data["username"].isalnum():
            raise ValueError("Username can only contain letters and numbers")
        if len(input_data["password"]) < 8:
            raise ValueError("Password must be at least 8 characters long")
        if "@" not in input_data["email"]:
            raise ValueError("Please enter a valid email address")
    
    def _validate_identity_verification_input(self, input_data: Dict[str, Any]):
        """Validate identity verification input."""
        required_fields = ["full_name", "date_of_birth", "government_id"]
        self._validate_required_fields(input_data, required_fields)
        
        if len(input_data["full_name"].split()) < 2:
            raise ValueError("Please enter your full name (first and last name)")
    
    def _validate_preferences_input(self, input_data: Dict[str, Any]):
        """Validate preferences input."""
        required_fields = ["language", "timezone", "notification_preferences"]
        self._validate_required_fields(input_data, required_fields)
        
        if input_data["notification_preferences"].lower() not in ["yes", "no"]:
            raise ValueError("Please answer 'yes' or 'no' for notification preferences")
    
    def _validate_required_fields(self, input_data: Dict[str, Any], required_fields: List[str]):
        """Validate that all required fields are present in the input."""
        missing_fields = [field for field in required_fields if field not in input_data]
        if missing_fields:
            raise ValueError(f"Missing required fields: {', '.join(missing_fields)}")


def collect_user_input(step_response: Dict[str, Any]) -> Dict[str, Any]:
    """Collect user input based on the current step requirements."""
    user_input = {}
    current_step = step_response["current_step"]
    
    print(f"\n=== {current_step.replace('_', ' ').title()} ===")
    print(step_response["message"])
    
    if current_step == "SECURITY_SETUP":
        return {}  # Handled separately in _collect_security_questions
    
    if "required_fields" in step_response:
        print("\nPlease provide the following information:")
        for field in step_response["required_fields"]:
            description = step_response.get("field_descriptions", {}).get(field, "")
            options = step_response.get("options", {}).get(field)
            
            while True:
                try:
                    if field == "password":
                        value = getpass(f"{field} ({description}): ")
                    else:
                        if options:
                            print(f"Available options for {field}: {', '.join(options)}")
                        prompt = f"{field}"
                        if description:
                            prompt += f" ({description})"
                        prompt += ": "
                        value = input(prompt)
                    
                    if not value.strip():
                        print("This field cannot be empty. Please try again.")
                        continue
                        
                    user_input[field] = value.strip()
                    break
                    
                except KeyboardInterrupt:
                    print("\nOperation cancelled by user.")
                    exit()
                except Exception as e:
                    print(f"Error: {e}. Please try again.")
    
    return user_input


def run_interactive_onboarding():
    """Run the onboarding process with interactive user input."""
    print("\n=== Digital Banking Onboarding ===\n")
    print("You'll be guided through a 5-step process to create your account.\n")
    
    agent = OnboardingAgent()
    step_response = None  # Initialize variable to avoid UnboundLocalError
    
    while True:
        try:
            step_response = agent.process_step()
            
            if step_response["current_step"] == "COMPLETION":
                print("\n" + "="*50)
                print(step_response["message"])
                print("\n=== Account Summary ===")
                
                summary = step_response["user_data_summary"]
                for section, data in summary.items():
                    print(f"\n{section.title()}:")
                    if isinstance(data, dict):
                        for key, value in data.items():
                            print(f"  {key}: {value}")
                    else:
                        print(f"  {data}")
                
                print("\n" + "="*50)
                print("\nNext actions available:")
                for action in step_response["next_actions"]:
                    print(f"- {action.replace('_', ' ').title()}")
                break
            
            if step_response.get("awaiting_input", False):
                user_input = collect_user_input(step_response)
                agent.process_step(user_input)
            else:
                agent.process_step()
                
        except KeyboardInterrupt:
            print("\nOnboarding process cancelled by user.")
            break
        except Exception as e:
            print(f"\nAn error occurred: {e}")
            if step_response and step_response.get("retry_step", False):
                print("Please try this step again.")
            else:
                print("Onboarding process failed.")
                break

#This code block is the entry point of the program when executed directly (not imported as a module).
if __name__ == "__main__":
    run_interactive_onboarding()